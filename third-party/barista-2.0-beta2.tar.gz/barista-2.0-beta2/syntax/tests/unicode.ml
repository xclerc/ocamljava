let x = "abc"

let y = [] @ []

let z = @"abc"

let t = @'x'

let u = 'c'

let f = function
  | @"abc" -> 0
  | @"def" when 1 == 1 -> 1
  | _ -> 2

let g = function
  | @'a' -> 0
  | @'b' -> 1
  | _ -> 2

let h = function
  | (_, _, x) -> x
