let name_value name value =
  SPRINTF ("%s: %d" name value)

let add_name buff name value =
  BPRINTF ("%s: %d\n" buff name value)

let zero = BPRINTF ("0" (get_buffer ()))

let one = SPRINTF ("%d" (succ 1))
