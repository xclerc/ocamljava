package pack;

public class TestDasm {

    private static int COUNTER;

    private static final float FIELD;

    private final int id;

    static {
        float f = 0.0f;
        for (int i = 0; i < 5; i++) {
            f += (float) (i * i);
        }
        FIELD = f;
    }

    public TestDasm() {
        this.id = COUNTER++;
    }

    public static int f(boolean b, int i, float f) {
        if (b) {
            return i - (int) f;
        } else {
            return i + (int) f;
        }
    }

    public long g(int x) {
        System.out.printf("TestDasm.g(%d)\n", x);
        return f(true, x, 1.0f);
    }

    public int sum(int... l) {
        int res = 0;
        for (int x : l) {
            res += x;
        }
        return res;
    }

}
