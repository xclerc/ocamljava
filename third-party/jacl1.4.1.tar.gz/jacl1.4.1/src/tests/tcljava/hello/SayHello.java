// This class is used to test loading of a .class file
// out of a jar that is on the TCL_CLASSPATH.

package hello;
public class SayHello {
    public static String hello() {
        return "hello";
    }
}

